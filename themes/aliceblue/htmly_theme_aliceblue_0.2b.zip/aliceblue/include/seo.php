<?php
    $seoo='';
    
    $author = config('seo.author');
    
	if(!empty($author))
		$seoo.= '<link href="'.$author.'" rel="author" />';
	
    
    $oglocale = config('seo.location');
    
	if(!empty($oglocale))
		$seoo.= '<meta content="'.$oglocale.'" property="og:locale" />';
	
    
    $ogtitle = blog_title();
    
	if(!empty($ogtitle))
		$seoo.= '<meta content="'.$ogtitle.'" property="og:title" />';
    
    
    $ogtype = config('seo.ogtype');
    
	if(!empty($ogtype))
		$seoo.= '<meta content="'.$ogtype.'" property="og:type" />';
	
    
    if(isset($p->url))
        $ogurl = $p->url;
    else 
        $ogurl='';
    
	if(!empty($ogurl))
		$seoo.= '<meta content="'.$ogurl.'" property="og:url" />';
	
    
    $ogsitename = config('blog.title');
    
	if(!empty($ogsitename))
		$seoo.= '<meta content="'.$ogsitename.'" property="og:site_name" />';
	
    

    if(isset($p->author))
        $articleauthor = $p->author;
    else
        $articleauthor=null;
    
	if(!empty($articleauthor))
		$seoo.= '<meta content="'.$articleauthor.'" property="article:author" />';
	
    
    $ogsitename = config('seo.location');
    
	if(!empty($ogsitename))
		$seoo.= '<meta content="'.$ogsitename.'" property="og:site_name" />';
	
    
    if(isset($p->date))
        $publishedtime = date('d F Y', $p->date);
    else
        $publishedtime=null;
    
	if(!empty($publishedtime))
		$seoo.= '<meta content="'.$publishedtime.'" property="article:published_time" />';
	
    
    $ogimagestandard = config('seo.ogimg');
    
    if(isset($p->body))
        $ogimage = get_thumbnail($p->body);
    else
        $ogimage=null;

	if(!empty($ogimagestandard))
		$seoo.= '<meta content="'.$ogimage.'" property="og:image" />';	
	
    elseif(empty($ogimage) and !empty($ogimagestandard))
		$seoo.= '<meta content="'.$ogimagestandard.'" property="og:image" />';
	
	
        
    if(isset($p->title))
        $ogtitle = $p->title;
    else
        $ogtitle=null;
    
	if(!empty($ogimagestandard))
		$seoo.= '<meta content="'.$ogtitle.'" property="og:site_name" />';
	

    $rsslink = site_url().'feed/rss';
    
    $seoo.= '<link href="'.$rsslink.'" title="'.$ogsitename.' » Feed" type="application/rss+xml" rel="alternate" />';
    
    $blogdescription = blog_description();    
    
    $seoo.= '<meta content="'.$blogdescription.'" itemprop="description" />';


/* Apple touch images */
    $ati = config('seo.ati');
	
    if(!empty($ati))
		$seoo.= '<link rel="apple-touch-icon" href="'.$ati.'" />';
	
    
    $ati76 = config('seo.ati76');
    
	if(!empty($ati76))
		$seoo.= '<link sizes="76x76" rel="apple-touch-icon" href="'.$ati76.'" />';
	
    
    $ati120 = config('seo.ati120');
    
	if(!empty($ati120))
		$seoo.= '<link rel="apple-touch-icon" href="'.$ati120.'" />';
	
    
    $ati152 = config('seo.ati152');
    
	if(!empty($ati152))
		$seoo.= '<link rel="apple-touch-icon" href="'.$ati152.'" />';
	
	
/* Apple Startup Image */
    $asi = config('seo.asi');
    
	if(!empty($asi))
		$seoo.= '<link rel="apple-touch-icon" href="'.$asi.'" />';
	
?>

<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
