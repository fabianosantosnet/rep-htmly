<?php if (!empty($breadcrumb)):?><div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php echo $breadcrumb ?></div><?php endif;?>
<?php if(login()) { echo tab($p);} ?>
<div class="post" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
	<div class="main static">
		<h1 class="title-post" itemprop="name"><?php echo $p->title ?></h1>
		<div class="post-body" itemprop="articleBody">
			<?php 
            
            #if(config('static.frontpage')==='true')            
                echo $p->body;
            #else
             #   echo 'teste2';
        ?>
		</div>
	</div>
</div>