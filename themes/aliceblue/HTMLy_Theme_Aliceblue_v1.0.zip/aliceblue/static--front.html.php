<?php require_once('functions.php');  if (!empty($breadcrumb)):?><div class="breadcrumb" xmlns:v="http://rdf.data-vocabulary.org/#"><?php echo $breadcrumb ?></div><?php endif;?>
<?php if(login()) { echo tab($p);} ?>
<div class="post" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
	<div class="main static">
		<!-- <h1 class="title-post" itemprop="name"><?php echo 'static front page' ?></h1> -->
		<div class="post-body" itemprop="articleBody">
			<?php 
            
            if(config('static.frontpage')==='false')            
                echo $p->body;
            else
            {   
                $dt = popular_posts(true,4);
                echo "<div class=\"feat-header\">
                        <h2 class=\"titlestatic\">".i18n_local('popular_posts')."</h2>";

                echo "<div class=\"content\">";
                
                for($i=0;$i<count($dt);$i++)
                {
                    $title=$dt[$i]->title;
                    $link=$dt[$i]->url;
                    $srcimg=$dt[$i]->image;
                    $altimg='';
                    $w='150';
                    $h='150';
                    $thumb=get_thumbnail($dt[$i]->body);
                    
                   echo "
                   <div>". $thumb. "
                        <a href=\"$link\">$title</a>
                   </div>
                   ";
                }  
                echo "</div>";
                echo "</div><br><br>";
            
                $dt=recent_posts(true,5);
                
                echo "<div class=\"feat-recents\">";
                
                echo "<h2 class=\"titlestatic\">".i18n_local('recent_posts')."</h2>";
                
                echo "<div class=\"content\">";
                
                for($i=0;$i<count($dt);$i++)
                {
                    $title=$dt[$i]->title;
                    $link=$dt[$i]->url;
                    $srcimg=featuredImage($dt[$i],'150','150',true);
                    $summary=get_teaser($dt[$i]->body, $dt[$i]->url);
                    $altimg='';
                    $w='150';
                    $h='60';
                    
                    if(strlen($srcimg)<=1) $srcimg="https://via.placeholder.com/".$w."x".$h."/069/fff?text=image";
                    
                   
                   echo "
                   <div>
                        <img src=\"$srcimg\" alt=\"$altimg\" width=\"$w\" height=\"$h\" />
                        <div>
                            <a href=\"$link\">$title</a>
                            <p>$summary</p>
                        </div>
                   </div>
                   ";
                }  
                
                echo "</div>";
                echo "</div>";
            }
        ?>
		</div>
	</div>
</div>