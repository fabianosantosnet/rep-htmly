<?php require_once('functions.php'); if (!empty($breadcrumb)):?>   <div class="breadcrumb"><?php echo $breadcrumb ?></div><?php endif;

        $i = 0;
        $len = count($posts);
        
        foreach($posts as $p):
		
			if ($i == 0) 
				$class = 'post first';
				
            elseif ($i == $len - 1) 
                $class = 'post last';

            else 
                $class = 'post';
            
			$i++;
    ?>    
        <div class="<?php echo $class ?>" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
    	<div class="main">
			<?php echo featuredLink($p) ?>
			<div class="metabar">
				<span class="date" itemprop="datePublished"><?php echo format_date($p->date); ?></span> - <?php echo i18n_local('posted_in') ?>
				<span class="tags" itemprop="articleSection"><?php echo $p->tag ?></span> <?php echo i18n_local('by') ?>
				<span class="Autor" itemprop="author"><a href="<?php echo $p->authorUrl ?>"><?php echo $p->author ?></a></span>
				<?php
					if (disqus_count())
                    {?>
                        <span class="comment"> - <a href="<?php echo $p->url?>#disqus_thread"><?php echo i18n_local('comments') ?></a></span>
					<?php 
                    }
                    elseif(facebook())
                    {?>
					   <a href="<?php echo $p->url ?>#comments"><span><fb:comments-count href=<?php echo $p->url ?>></fb:comments-count> - <?php echo i18n_local('comments') ?></span></a>
					<?php 
                    }?>
			</div>
			<div class="teaser-body" itemprop="articleBody">
            
              <?php featuredImage($p) ?>
              <?php echo featuredVideo($p) ?>
              <?php echo featuredAudio($p) ?>
              <?php echo featuredQuote($p) ?>            
              <?php echo featuredGetThumb($p) ?>
              <?php echo '<p>'.get_teaser($p->body, $p->url).'</p>' ?>
              
			</div>
    </div>
   
    <?php endforeach;?>

    <?php if (!empty($pagination['prev']) || !empty($pagination['next'])):?>
        <div class="pager">
            <?php if (!empty($pagination['prev'])):?>
                <span><a href="?page=<?php echo $page-1?>" class="pagination-arrow newer" rel="prev"><?php echo ucfirst(i18n_local('newer'))?></a></span>
            <?php endif;?>
            <?php if (!empty($pagination['next'])):?>
                <span><a href="?page=<?php echo $page+1?>" class="pagination-arrow older" rel="next"><?php echo ucfirst(i18n_local('older'))?></a></span>
            <?php endif;?>
        </div>
    <?php endif;?>

    <?php if(disqus_count()):?>
    <?php echo disqus_count() ?>
    <?php endif;?>