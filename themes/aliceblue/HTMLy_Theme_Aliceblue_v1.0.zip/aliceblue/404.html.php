<?php require_once('functions.php');?><div class="post first" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
    <div class="main">
        <h1 class="title-index" itemprop="name"><?php echo i18n_local('sorry_the_page_you_try_to_access_doesnt_exist') ?></a></h1>                 
        <img src="<?php echo site_url().$THEMEIMG ?>/not-found.png" class="warn">
    </div>
</div>  
