    <?php if (!empty($breadcrumb)):?><div class="breadcrumb"><?php echo $breadcrumb ?></div><?php endif;?>
    	<?php $i = 0; $len = count($posts);?>
		<?php foreach($posts as $p):?>
		<?php
			if ($i == 0) {
				$class = 'post first';
				}
				elseif ($i == $len - 1) {
					$class = 'post last';
				}
				else {
					$class = 'post';
				}
				$i++;
    ?>
    <div class="<?php echo $class ?>" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
    	<div class="main">
			<h2 class="title-index" itemprop="name"><a href="<?php echo $p->url?>"><?php echo $p->title ?></a></h2>
			<div class="metabar">
				<span class="date" itemprop="datePublished"><?php echo format_date($p->date); ?></span> - Posted in
				<span class="tags" itemprop="articleSection"><?php echo $p->tag ?></span> by
				<span class="Autor" itemprop="author"><a href="<?php echo $p->authorUrl ?>"><?php echo $p->author ?></a></span>
				<?php
					if (disqus_count()) {?><span class="comment"> - <a href="<?php echo $p->url?>#disqus_thread">Comments</a></span>
					<?php } elseif (facebook()){ ?>
					<a href="<?php echo $p->url ?>#comments"><span><fb:comments-count href=<?php echo $p->url ?>></fb:comments-count> - Comments</span></a>
					<?php } ?>
			</div>
			<div class="teaser-body" itemprop="articleBody">
				<?php echo get_thumbnail($p->body)?>
				<?php echo get_teaser($p->body, $p->url)?>
			</div>
    </div>
   
    <?php endforeach;?>

<?php if (!empty($pagination['prev']) || !empty($pagination['next'])): ?>
    <div class="pager">
        <div class="pagination"><?php echo $pagination['html'];?></div>
    </div>
<?php endif; ?>

    <?php if (disqus_count()):?>
    <?php echo disqus_count() ?>
    <?php endif;?>