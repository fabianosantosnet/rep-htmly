<?php

	$bgimage = config('my.bgimage');
	if(empty($bgimage)){
		$bgimage = "";
	};
?>
<style>
	@media screen and (min-device-width: 651px){
		body{ background-image:url(<?php echo $bgimage;?>)}
	}
</style>