<?php require_once('functions.php');?><div class="post first" itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
    <div class="main">
        <h1 class="title-index" itemprop="name">This page doesn't exist!</a></h1>                 
        <img src="<?php echo site_url().$THEMEIMG ?>/not-found.png" class="warn">
    </div>
</div>  
