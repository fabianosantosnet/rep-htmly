<?php
## GLOBALS VARS
$d= explode('themes',str_replace('\\','/',__FILE__));
$d=explode('/',$d[1]);
$THEMEDIR='themes/'.$d[1].'/';
$THEMEIMG=$THEMEDIR.'img/';
$THEMEJS=$THEMEDIR.'js/';
$THEMECSS=$THEMEDIR.'css/';
#$THEMELANG=$THEMEDIR.'lang/';
?>