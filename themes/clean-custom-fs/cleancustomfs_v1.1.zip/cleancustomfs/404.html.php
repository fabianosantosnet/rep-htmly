<?php require_once('functions.php');?>
<?php if (!empty($breadcrumb)): ?>
    <div class="breadcrumb"><?php echo $breadcrumb ?></div>
<?php endif; ?>
<div class="post">
    <div class="main">
        <h1 class="title-post"><?php echo i18n_local('Page_not_found') ?></h1>
        <p><?php echo i18n_local('Sorry_the_page_you_try_to_access_doesnt_exist') ?></p>
        <p><?php echo i18n_local('Please_use_the_search_to_find_what_you_are_looking_for_or_go_to') ?> <a href="<?php echo site_url() ?>"><?php echo i18n_local('start_page') ?></a>.</p>
        <p><img src="<?php echo site_url().$THEMEIMG ?>error-page-error404.jpg" alt="sorry" style="width:180px" /></p>                
    </div>
</div>
