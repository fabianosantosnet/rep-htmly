<?php
## GLOBALS VARS
$d= explode('themes',str_replace('\\','/',__FILE__));
$d=explode('/',$d[1]);
$THEMEDIR='themes/'.$d[1].'/';
$THEMEIMG=$THEMEDIR.'img/';
$THEMEJS=$THEMEDIR.'js/';
$THEMECSS=$THEMEDIR.'css/';
$THEMELANG=$THEMEDIR.'lang/';

if( !($THEMEFONT=config('cleancustomfs.defaultSiteFont')) ) $THEMEFONT='//fonts.googleapis.com/css?family=Open+Sans+Condensed:700&subset=latin,cyrillic-ext';

// local internationalization based on system/includes/dispatch.php
// set your language inside 'lang' folder -> en_US.ini for English, pt_BR.ini for Portuguese etc... (create your lang_XXX.ini and translate keys)

function i18n_local($key, $value = null)
{
    static $_i18n = array();

	if( !($_i18n_local = @parse_ini_file(dirname(__FILE__).'/lang/'.config('language').'.ini', true)) )
	
		$_i18n_local = @parse_ini_file(dirname(__FILE__).'/lang/en_US.ini', true);
	
	return (isset($_i18n_local[$key]) ? $_i18n_local[$key] : '_i18n_' . $key . '_i18n_');	
}

function pager() #not working yet
{
	#$pagination=$GLOBALS['pagination'];
	#$page=$GLOBALS['page'];
	global $page;
	echo $page;
	?>
    <div class="pager">
        <?php if (!empty($pagination['prev'])): ?>
            <span><a href="?page=<?php echo $page - 1 ?>" class="pagination-arrow newer" rel="prev"><?php echo i18n_local('newer_page');?></a></span>
        <?php endif; ?>
         <span class="page-number"><?php echo $pagination['pagenum']; ?></span>
        <?php if (!empty($pagination['next'])): ?>
            <span><a href="?page=<?php echo $page + 1 ?>" class="pagination-arrow older" rel="next"><?php echo i18n_local('older_page');?></a></span>
        <?php endif; ?>
    </div><?php	
}


function newsletter()
{ 
#feedburner.idname    
?>
                <h3><?php echo i18n_local('newsletter');?></h3>
                <div class="followbyemail">
                    <div class="widget-content">
                        <div class="follow-by-email-inner">
                            <form action="https://feedburner.google.com/fb/a/mailverify" method="post" onsubmit="window.open(&quot;https://feedburner.google.com/fb/a/mailverify?uri=<?php echo config('feedburner.idname') ?>&quot;, &quot;popupwindow&quot;, &quot;scrollbars=yes,width=550,height=520&quot;); return true" target="popupwindow">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <input class="follow-by-email-address" name="email" placeholder="<?php echo i18n_local('emailplaceholder');?>" type="email">
                                            </td>
                                            <td>
                                                <input class="follow-by-email-submit" type="submit" value="<?php echo i18n_local('sent');?>">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <input name="uri" type="hidden" value="<?php echo config('feedburner.idname') ?>">
                                <input name="loc" type="hidden" value="<?php echo config('language') ?>">
                            </form>
                        </div>
                    </div>
                </div>
<?php
}


function returnSubPageLinks($pURL)
{
    $static = substr($pURL, strrpos($pURL, "/") + 1);
    $sb = get_static_sub_post($static, null);
    
    $links='';
    if(count($sb)>0)     
       $links.='<h5>'.i18n_local('subpages_title').'</h5>';
    
    foreach($sb as $p)
      $links.= '<a href="' . $p->url . '">' . get_title_from_file($p->file) . '</a><br>';    
     
    if(strlen($links)>10)
        return '<div class="subpages">'.$links.'</div>';
    else
        return $links;
}


function social_local($imgDir = null)
{
    $url=site_url();
    $twitter = config('social.twitter');
    $facebook = config('social.facebook');
    $tumblr = config('social.tumblr');
    $instagram = config('social.instagram');
    $telegram = config('social.telegram');
    $youtube = config('social.youtube');
    $whatsapp = config('social.whatsapp');
    $rss = site_url() . 'feed/rss';

    if (!empty($twitter)) {
        echo '<a href="' . $twitter . '" target="_blank"><img src="' . site_url() .  $imgDir . 'twitter.png" width="32" height="32" alt="Twitter"/></a>';
    }

    if (!empty($facebook)) {
        echo '<a href="' . $facebook . '" target="_blank"><img src="' . site_url() .  $imgDir . 'facebook.png" width="32" height="32" alt="Facebook"/></a>';
    }

    if (!empty($tumblr)) {
        echo '<a href="' . $tumblr . '" target="_blank"><img src="' . site_url() .  $imgDir . 'tumblr.png" width="32" height="32" alt="Tumblr"/></a>';
    }

    if (!empty($instagram)) {
        echo '<a href="' . $instagram . '" target="_blank"><img src="' . site_url() .  $imgDir . 'instagram.png" width="32" height="32" alt="Instagram"/></a>';
    }
    
    if (!empty($telegram)) {
        echo '<a href="' . $instagram . '" target="_blank"><img src="' . site_url() .  $imgDir . 'telegram.png" width="32" height="32" alt="Telegram"/></a>';
    }    

    if (!empty($whatsapp)) {
        echo '<a href="https://api.whatsapp.com/send?phone=' . $whatsapp . '&text='.$url.'" target="_blank"><img src="' . $url .  $imgDir . 'whatsapp.png" width="32" height="32" alt="WhatsApp"/></a>';
    }    
    
    if (!empty($youtube)) {
        echo '<a href="' . $youtube . '" target="_blank"><img src="' . site_url() .  $imgDir . 'youtube.png" width="32" height="32" alt="Youtube"/></a>';
    }        
    
    echo '<a href="' . $rss . '" target="_blank"><img src="' . site_url() .  $imgDir . 'rss.png" width="32" height="32" alt="RSS Feed"/></a>';
}

?>