## NAME Clean Custom FS

## DATE 05/23/2021

## Version 1.1

## Description
This is a customized version of Default Clean Theme. It contains 3 columns.

v1.0
  Options available:
   - in Config->Custom, set:
     > feedburner.idname (string) -> 'username or identification'
     > cleancustomfs.toolbar (bool) -> true (show toolbar while login is active)
     > cleancustomfs.show.comments (bool) - set true to show link on home page to comments
     > cleancustomfs.show.author (bool) - set true to show the author's name on home page

v1.1
  
  Included subpages support only for static pages
  Widget Counter works only if you disable cache (Config->Performance->Disable Cache - set Yes)

  New options available:

   = in Config->Custom, create a var (or edit config/config.ini and add it - ONLY ADVANCED USERS):
      - New Widget Counter (only for pages and posts)
        cleancustomfs.DisableCounterWidget (bool) - true value disable it

      - Custom Widget (for CSS it uses '.custom' class) 
           cleancustomfs.EnableCustomWidget (bool) - true to show
              after that you can use the following:
                  cleancustomfs.CustomWidgetTitle (string) - write your title
		  cleancustomfs.CustomWidgetData (string) - write an text, HTML, JS or CSS

      - Enable Feedburner Widget (according to google this service will end this year 2021)
        cleancustomfs.EnableFeedBurnerWidget (bool) - true to show this widget

      - Change site's font
        cleancustomfs.defaultSiteFont (string) = default value if not set => '//fonts.googleapis.com/css?family=Open+Sans+Condensed:700&subset=latin,cyrillic-ext'
         * visit google fonts or other source like onlinewebfonts.com - to work properly you need to change /css/style.css theme file replacing 'Open Sans Condensed' with a new font name

      - Enable thumbnail image fallback for regular posts only on home page (it works only when posts are marked as 'trimmed' to avoid duplicated images - edit line 72 of main.html if you want to change its behavior)
        cleancustomfs.DisableThumbnailHome (bool) - true value to disable it

      - New icons for social links below logo => instagram, whatsapp, telegram and youtube
	social.whatsapp (string) - set only your phone number
	social.youtube (string) - set the complete URL
	social.instagram (string)
	social.telegram (string)
	social.twitter (string)
	social.facebook (string)
	social.tumblr (string)
	
## Credits
   HTMLy.com   
   Customized version by @fabianosantosnet