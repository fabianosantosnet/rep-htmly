<?php require_once('functions.php');?>
<h1><?php echo i18n_local('no_posts_found');?></h1>