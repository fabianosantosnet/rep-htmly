<?php require_once('functions.php');?><!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <?php echo head_contents() ?>
    
    <title><?php echo $title;?></title>

    <meta name="description" content="<?php echo $description; ?>" />

    <link rel="canonical" href="<?php echo $canonical; ?>" />
    <link href="<?php echo site_url().$THEMECSS ?>style.css" rel="stylesheet" />
    <link href="//fonts.googleapis.com/css?family=Open+Sans+Condensed:700&subset=latin,cyrillic-ext" rel="stylesheet" />

</head>

<body class="<?php echo $bodyclass; ?>" itemscope="itemscope" itemtype="http://schema.org/Blog">
    <div id="wrapper">
        <div class="hide">
            <meta content="<?php echo blog_title() ?>" itemprop="name" />
            <meta content="<?php echo blog_description() ?>" itemprop="description" />
        </div>
        
        <?php if (facebook()) { echo facebook(); } ?>
        <?php if (login()) { if( config('cleancustomfs.toolbar')==='true') toolbar(); } ?>
        
        <aside id="left">
            <div id="logo">
                <?php if (is_index()) { ?>
                <h1 class="blog-title"><a rel="home" href="<?php echo site_url() ?>"><?php echo blog_title() ?></a></h1>
                <?php } else { ?>
                <h2 class="blog-title"><a rel="home" href="<?php echo site_url() ?>"><?php echo blog_title() ?></a></h2>
                <?php } ?>
                <div class="bdesc"><?php echo blog_description() ?></div>
                <div class="btagline"><?php echo blog_tagline() ?></div>
            </div>
            
            <div class="social">
                <?php echo social() ?>
            </div>
            <div class="menu">
                <?php echo menu() ?>
            </div>
            <div class="category-list">
                <h3><?php echo i18n_local('categories');?></h3>
                <?php echo category_list() ?>
            </div>
            <div class="recent">
                <h3><?php echo i18n_local('posts_newer');?></h3>
                <?php echo recent_posts() ?>
            </div>
            <div class="tagcloud">
                <h3><?php echo i18n_local('cloud_tags');?></h3>
                <?php echo tag_cloud() ?>
            </div>
        </aside>
        
        <section id="content">
            <?php echo content() ?>
        </section>
        
        <aside id="right">
            <div class="search">
                <?php echo search() ?>
            </div>
    	
            <div class="rnews">
            <?php newsletter(); ?>
            </div>
    		
            <div class="archive">
                <h3><?php echo i18n_local('archives');?></h3>
                <?php echo archive_list() ?>
            </div>
    	
            <div class="morevisits">
                <h3><?php echo i18n_local('popular_posts');?></h3>
                <?php echo popular_posts() ?>
            </div>
    		
        </aside>
        <?php if (analytics()): ?>
        <?php echo analytics() ?>
        <?php endif; ?>
        <footer>
            <div class="copyright">&copy; <?php echo config('blog.copyright');?></div>
        </footer>
    </div>   
</body>
</html>