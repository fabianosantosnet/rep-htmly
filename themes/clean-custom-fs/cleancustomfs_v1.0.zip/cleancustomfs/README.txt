## NAME Clean Custom FS

## DATE 04/21/2021

## Version 1.0

## Description
This is a customized version of Default Clean Theme. It contains 3 columns.

  Options available:
   - in Config->Custom, set:
     > feedburner.idname (string) -> 'username or identification'
	 > cleancustomfs.toolbar (bool) -> true (show toolbar while login is active)
	 > cleancustomfs.show.comments (bool) - set true to show link to comments
	 > cleancustomfs.show.author (bool) - set true to show the author's name


## Credits
   HTMLy.com
   Customized version by @fabianosantosnet