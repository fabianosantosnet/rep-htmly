<?php
## GLOBALS VARS
$d= explode('themes',str_replace('\\','/',__FILE__));
$d=explode('/',$d[1]);
$THEMEDIR='themes/'.$d[1].'/';
$THEMEIMG=$THEMEDIR.'img/';
$THEMEJS=$THEMEDIR.'js/';
$THEMECSS=$THEMEDIR.'css/';
$THEMELANG=$THEMEDIR.'lang/';

// local internationalization based on system/includes/dispatch.php
// set your language inside 'lang' folder -> en_US.ini for English, pt_BR.ini for Portuguese etc... (create your lang_XXX.ini and translate keys)

function i18n_local($key, $value = null)
{
    static $_i18n = array();

	if( !($_i18n_local = @parse_ini_file(dirname(__FILE__).'/lang/'.config('language').'.ini', true)) )
	
		$_i18n_local = @parse_ini_file(dirname(__FILE__).'/lang/en_US.ini', true);
	
	return (isset($_i18n_local[$key]) ? $_i18n_local[$key] : '_i18n_' . $key . '_i18n_');	
}

function pager()
{
	#$pagination=$GLOBALS['pagination'];
	#$page=$GLOBALS['page'];
	global $page;
	echo $page;
	?>
    <div class="pager">
        <?php if (!empty($pagination['prev'])): ?>
            <span><a href="?page=<?php echo $page - 1 ?>" class="pagination-arrow newer" rel="prev"><?php echo i18n_local('newer_page');?></a></span>
        <?php endif; ?>
         <span class="page-number"><?php echo $pagination['pagenum']; ?></span>
        <?php if (!empty($pagination['next'])): ?>
            <span><a href="?page=<?php echo $page + 1 ?>" class="pagination-arrow older" rel="next"><?php echo i18n_local('older_page');?></a></span>
        <?php endif; ?>
    </div><?php	
}


function newsletter()
{
    
#feedburner.idname    
?>
                <h3><?php echo i18n_local('newsletter');?></h3>
                <div class="followbyemail">
                    <div class="widget-content">
                        <div class="follow-by-email-inner">
                            <form action="https://feedburner.google.com/fb/a/mailverify" method="post" onsubmit="window.open(&quot;https://feedburner.google.com/fb/a/mailverify?uri=<?php echo config('feedburner.idname') ?>&quot;, &quot;popupwindow&quot;, &quot;scrollbars=yes,width=550,height=520&quot;); return true" target="popupwindow">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <input class="follow-by-email-address" name="email" placeholder="<?php echo i18n_local('emailplaceholder');?>" type="email">
                                            </td>
                                            <td>
                                                <input class="follow-by-email-submit" type="submit" value="<?php echo i18n_local('sent');?>">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <input name="uri" type="hidden" value="<?php echo config('feedburner.idname') ?>">
                                <input name="loc" type="hidden" value="<?php echo config('language') ?>">
                            </form>
                        </div>
                    </div>
                </div>
<?php
}
?>